import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  StatusBar
} from 'react-native';

const ACADEMIC_MONTHS = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

export default function App() {
  // Navigation simulator state
  const [currentScreen, setCurrentScreen] = useState('home');

  // Login States
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Monthly Tracking / Directory States
  const [selectedMonth, setSelectedMonth] = useState('Jun');
  const [batchFilter, setBatchFilter] = useState('All'); // 'All' | 'Morning' | 'Evening'

  // Form Field States
  const [name, setName] = useState('');
  const [studentClass, setStudentClass] = useState('');
  const [batch, setBatch] = useState('Morning'); // Default batch assignment state
  const [phone, setPhone] = useState('');
  const [amount, setAmount] = useState('');
  
  // Seed initial expanded records
  const [students, setStudents] = useState([
    {
      id: '1',
      name: 'Arjun Mehta',
      class: 'Class 10',
      batch: 'Morning',
      phone: '9876543210',
      history: [
        { month: 'Jun', amount: '2500', status: 'Paid' },
        { month: 'May', amount: '2500', status: 'Paid' }
      ]
    },
    {
      id: '2',
      name: 'Priya Rai',
      class: 'Class 12',
      batch: 'Evening',
      phone: '9123456789',
      history: [
        { month: 'Jun', amount: '3000', status: 'Pending' }
      ]
    }
  ]);

  const handleLogin = () => {
    setCurrentScreen('home');
  };

  const handleAddStudent = () => {
    if (!name.trim() || !amount.trim() || !studentClass.trim() || !phone.trim()) return;

    setStudents((prevStudents) => {
      const studentIndex = prevStudents.findIndex(
        (s) => s.name.toLowerCase() === name.trim().toLowerCase()
      );

      if (studentIndex > -1) {
        // Existing Student: Appends active monthly ledger record if missing
        const updatedStudents = [...prevStudents];
        const monthExists = updatedStudents[studentIndex].history.some(
          (h) => h.month === selectedMonth
        );

        if (!monthExists) {
          updatedStudents[studentIndex].history.push({
            month: selectedMonth,
            amount: amount.trim(),
            status: 'Pending',
          });
        }
        return updatedStudents;
      } else {
        // New Student: Allocates deep profile configuration object
        return [
          {
            id: Date.now().toString(),
            name: name.trim(),
            class: studentClass.trim(),
            batch: batch,
            phone: phone.trim(),
            history: [
              {
                month: selectedMonth,
                amount: amount.trim(),
                status: 'Pending',
              },
            ],
          },
          ...prevStudents,
        ];
      }
    });

    // Reset input fields
    setName('');
    setStudentClass('');
    setPhone('');
    setAmount('');
  };

  const createMissingInvoice = (studentId, defaultAmount) => {
    setStudents((prevStudents) =>
      prevStudents.map((student) => {
        if (student.id !== studentId) return student;
        return {
          ...student,
          history: [
            ...student.history,
            { month: selectedMonth, amount: defaultAmount || '2000', status: 'Pending' }
          ]
        };
      })
    );
  };

  const toggleStatus = (studentId) => {
    setStudents((prevStudents) =>
      prevStudents.map((student) => {
        if (student.id !== studentId) return student;
        return {
          ...student,
          history: student.history.map((record) =>
            record.month === selectedMonth
              ? { ...record, status: record.status === 'Paid' ? 'Pending' : 'Paid' }
              : record
          ),
        };
      })
    );
  };

  // --- RENDERING FILTER PIPELINE ---
  const filteredStudents = students.filter((student) => {
    if (batchFilter === 'All') return true;
    return student.batch === batchFilter;
  });

  // --- DYNAMIC DASHBOARD AGGREGATIONS (Evaluated over overall directory scope matching active month context) ---
  const activeStudentsThisMonth = students.filter((s) =>
    s.history.some((h) => h.month === selectedMonth)
  ).length;

  const totalFeesExpected = students.reduce((sum, student) => {
    const record = student.history.find((h) => h.month === selectedMonth);
    return sum + (record ? parseFloat(record.amount) || 0 : 0);
  }, 0);

  const totalFeesPending = students.reduce((sum, student) => {
    const record = student.history.find((h) => h.month === selectedMonth);
    return sum + (record && record.status === 'Pending' ? parseFloat(record.amount) || 0 : 0);
  }, 0);

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <StatusBar barStyle="light-content" />
      {currentScreen === 'login' ? (
        /* --- LOGIN SCREEN --- */
        <View style={styles.innerContainer}>
          <Text style={styles.title}>Welcome Back</Text>
          <Text style={styles.subtitle}>Sign in to your dashboard</Text>

          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor="#64748B"
            keyboardType="email-address"
            autoCapitalize="none"
            value={email}
            onChangeText={setEmail}
          />

          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#64748B"
            secureTextEntry
            autoCapitalize="none"
            value={password}
            onChangeText={setPassword}
          />

          <TouchableOpacity style={styles.button} onPress={handleLogin}>
            <Text style={styles.buttonText}>Log In</Text>
          </TouchableOpacity>
        </View>
      ) : (
        /* --- HOME SCREEN --- */
        <FlatList
          data={filteredStudents}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.scrollContainer}
          ListHeaderComponent={
            <View>
              <View style={styles.headerRow}>
                <Text style={styles.titleLeft}>Dashboard</Text>
                <TouchableOpacity onPress={() => setCurrentScreen('login')}>
                  <Text style={styles.logoutText}>Logout</Text>
                </TouchableOpacity>
              </View>

              {/* HORIZONTAL MONTH SELECTOR */}
              <View style={styles.monthScrollContainer}>
                <FlatList
                  horizontal
                  data={ACADEMIC_MONTHS}
                  keyExtractor={(item) => item}
                  showsHorizontalScrollIndicator={false}
                  renderItem={({ item }) => (
                    <TouchableOpacity
                      style={[styles.monthTab, selectedMonth === item && styles.monthTabActive]}
                      onPress={() => setSelectedMonth(item)}
                    >
                      <Text style={[styles.monthTabText, selectedMonth === item && styles.monthTabTextActive]}>
                        {item}
                      </Text>
                    </TouchableOpacity>
                  )}
                />
              </View>

              {/* METRICS DISPATCH COMPONENT */}
              <View style={styles.statsContainer}>
                <View style={styles.statsCard}>
                  <Text style={styles.statsLabel}>Active Students</Text>
                  <Text style={styles.statsValue}>{activeStudentsThisMonth}</Text>
                </View>
                <View style={styles.statsCard}>
                  <Text style={styles.statsLabel}>{selectedMonth} Fees</Text>
                  <Text style={[styles.statsValue, { color: '#6366F1' }]}>₹{totalFeesExpected}</Text>
                </View>
                <View style={styles.statsCard}>
                  <Text style={styles.statsLabel}>Pending</Text>
                  <Text style={[styles.statsValue, { color: '#EF4444' }]}>₹{totalFeesPending}</Text>
                </View>
              </View>

              {/* STYLISH FORM COMPONENT */}
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder="Student Name"
                  placeholderTextColor="#64748B"
                  value={name}
                  onChangeText={setName}
                />
                
                <View style={styles.rowInputs}>
                  <TextInput
                    style={[styles.input, { flex: 1, marginRight: 8 }]}
                    placeholder="Class / Course"
                    placeholderTextColor="#64748B"
                    value={studentClass}
                    onChangeText={setStudentClass}
                  />
                  <TextInput
                    style={[styles.input, { flex: 1 }]}
                    placeholder="Phone Number"
                    placeholderTextColor="#64748B"
                    keyboardType="phone-pad"
                    value={phone}
                    onChangeText={setPhone}
                  />
                </View>

                {/* BATCH SELECTOR TOGGLE SEGMENT */}
                <View style={styles.toggleGroupContainer}>
                  <Text style={styles.inlineLabel}>Form Batch:</Text>
                  <View style={styles.toggleGroup}>
                    <TouchableOpacity 
                      style={[styles.toggleOption, batch === 'Morning' && styles.toggleOptionActive]}
                      onPress={() => setBatch('Morning')}
                    >
                      <Text style={[styles.toggleOptionText, batch === 'Morning' && styles.toggleOptionTextActive]}>Morning</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={[styles.toggleOption, batch === 'Evening' && styles.toggleOptionActive]}
                      onPress={() => setBatch('Evening')}
                    >
                      <Text style={[styles.toggleOptionText, batch === 'Evening' && styles.toggleOptionTextActive]}>Evening</Text>
                    </TouchableOpacity>
                  </View>
                </View>

                <TextInput
                  style={styles.input}
                  placeholder={`Fee Amount for ${selectedMonth} (₹)`}
                  placeholderTextColor="#64748B"
                  keyboardType="numeric"
                  value={amount}
                  onChangeText={setAmount}
                />

                <TouchableOpacity style={styles.button} onPress={handleAddStudent}>
                  <Text style={styles.buttonText}>Submit Record</Text>
                </TouchableOpacity>
              </View>

              {/* BATCH RENDER FILTER SECTION MODULE */}
              <View style={styles.directoryHeader}>
                <Text style={styles.sectionTitle}>Students Directory</Text>
                <View style={styles.filterPillContainer}>
                  {['All', 'Morning', 'Evening'].map((type) => (
                    <TouchableOpacity
                      key={type}
                      style={[styles.filterPill, batchFilter === type && styles.filterPillActive]}
                      onPress={() => setBatchFilter(type)}
                    >
                      <Text style={[styles.filterPillText, batchFilter === type && styles.filterPillTextActive]}>
                        {type}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </View>
          }
          renderItem={({ item }) => {
            const currentMonthRecord = item.history.find((h) => h.month === selectedMonth);

            return (
              <View style={styles.listItem}>
                <View style={{ flex: 1, marginRight: 8 }}>
                  <View style={styles.nameRow}>
                    <Text style={styles.studentName} numberOfLines={1}>{item.name}</Text>
                    <View style={styles.batchIndicatorBadge}>
                      <Text style={styles.batchIndicatorText}>{item.batch[0]}</Text>
                    </View>
                  </View>
                  <Text style={styles.studentSubtext}>{item.class} • Vol: {item.phone}</Text>
                  {currentMonthRecord ? (
                    <Text style={styles.studentAmount}>₹{currentMonthRecord.amount}</Text>
                  ) : (
                    <Text style={[styles.studentAmount, { color: '#64748B' }]}>No invoice generated</Text>
                  )}
                </View>

                {currentMonthRecord ? (
                  <TouchableOpacity
                    style={[
                      styles.statusBadge,
                      currentMonthRecord.status === 'Paid' ? styles.badgePaid : styles.badgePending,
                    ]}
                    onPress={() => toggleStatus(item.id)}
                  >
                    <Text style={[styles.statusText, { color: currentMonthRecord.status === 'Paid' ? '#22C55E' : '#EF4444' }]}>
                      {currentMonthRecord.status}
                    </Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    style={styles.invoiceCreationButton}
                    onPress={() => createMissingInvoice(item.id, '2000')}
                  >
                    <Text style={styles.invoiceCreationText}>+ Invoice</Text>
                  </TouchableOpacity>
                )}
              </View>
            );
          }}
          ListEmptyComponent={<Text style={styles.emptyText}>No records match current filters.</Text>}
        />
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0B1220',
  },
  innerContainer: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  scrollContainer: {
    paddingTop: 50,
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: '#E5E7EB',
    textAlign: 'center',
  },
  titleLeft: {
    fontSize: 26,
    fontWeight: '700',
    color: '#E5E7EB',
  },
  directoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#94A3B8',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  subtitle: {
    fontSize: 15,
    color: '#94A3B8',
    marginBottom: 36,
    textAlign: 'center',
  },
  monthScrollContainer: {
    marginBottom: 20,
    height: 40,
  },
  monthTab: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#111827',
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#1F2937',
    justifyContent: 'center',
  },
  monthTabActive: {
    backgroundColor: '#6366F1',
    borderColor: '#6366F1',
  },
  monthTabText: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
  },
  monthTabTextActive: {
    color: '#FFFFFF',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8,
    marginBottom: 20,
  },
  statsCard: {
    flex: 1,
    backgroundColor: '#111827',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#1F2937',
  },
  statsLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: '#94A3B8',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  statsValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#E5E7EB',
  },
  inputContainer: {
    marginBottom: 20,
  },
  rowInputs: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  input: {
    backgroundColor: '#111827',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 10,
    fontSize: 15,
    color: '#E5E7EB',
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#1F2937',
  },
  toggleGroupContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#111827',
    padding: 8,
    borderRadius: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#1F2937',
  },
  inlineLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '500',
    paddingLeft: 8,
  },
  toggleGroup: {
    flexDirection: 'row',
    backgroundColor: '#0B1220',
    padding: 4,
    borderRadius: 8,
  },
  toggleOption: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 6,
  },
  toggleOptionActive: {
    backgroundColor: '#1F2937',
  },
  toggleOptionText: {
    color: '#64748B',
    fontSize: 13,
    fontWeight: '600',
  },
  toggleOptionTextActive: {
    color: '#E5E7EB',
  },
  filterPillContainer: {
    flexDirection: 'row',
    backgroundColor: '#111827',
    padding: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#1F2937',
  },
  filterPill: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
    marginLeft: 4,
  },
  filterPillActive: {
    backgroundColor: '#6366F1',
  },
  filterPillText: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
  },
  filterPillTextActive: {
    color: '#FFFFFF',
  },
  button: {
    backgroundColor: '#6366F1',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '600',
  },
  logoutText: {
    color: '#94A3B8',
    fontSize: 15,
    fontWeight: '500',
  },
  listItem: {
    backgroundColor: '#111827',
    padding: 14,
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#1F2937',
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
  },
  studentName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#E5E7EB',
    marginRight: 6,
    maxWidth: '80%',
  },
  batchIndicatorBadge: {
    backgroundColor: '#1F2937',
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 4,
  },
  batchIndicatorText: {
    color: '#94A3B8',
    fontSize: 10,
    fontWeight: '700',
  },
  studentSubtext: {
    fontSize: 12,
    color: '#64748B',
    marginBottom: 4,
  },
  studentAmount: {
    fontSize: 14,
    fontWeight: '600',
    color: '#94A3B8',
  },
  statusBadge: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 8,
    borderWidth: 1,
  },
  badgePaid: {
    backgroundColor: 'rgba(34, 197, 94, 0.1)',
    borderColor: 'rgba(34, 197, 94, 0.2)',
  },
  badgePending: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderColor: 'rgba(239, 68, 68, 0.2)',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  invoiceCreationButton: {
    backgroundColor: 'rgba(99, 102, 241, 0.1)',
    borderColor: 'rgba(99, 102, 241, 0.3)',
    borderWidth: 1,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  invoiceCreationText: {
    color: '#6366F1',
    fontSize: 12,
    fontWeight: '600',
  },
  emptyText: {
    textAlign: 'center',
    color: '#94A3B8',
    marginTop: 30,
    fontSize: 14,
  },
});
